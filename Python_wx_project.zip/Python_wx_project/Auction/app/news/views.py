
from rest_framework.response import Response
from rest_framework.decorators import action
from rest_framework import viewsets
from libs.yuntongxun.example.SendMessage import send_message
from serializer.Ser_check import NewsSerializer
from django_redis import get_redis_connection
import re
from app.user.models import UserInfo
from app.news.models import News,New_detail,New_image,Topic,New_Topic
from Auction import settings
import json

from sts.sts import Sts

class NewsViewSet(viewsets.ViewSet):

    @action(methods=['post'],url_path="new",detail=False)
    def put_news(self,request):
        """
        发布新闻动态
        Param:
            {
                ImageList : 图片列表
                text : 正文
                address : 位置
                topic : 话题
                title : 标题
                phone : 电话
            }
        return: 
            {
                success : True 
            }
        """
        # 1. 获取数据
        data = request.data
        image_list = data["ImageList"]
        text = data["text"]
        address = data["address"]
        title = data['title']
        topic = data["topic"]
        phone = data['phone']

        # 2. 校验参数
        serializer = NewsSerializer(data=data)
        if not serializer.is_valid():
            return Response({"success":False,"msg":"正文或标题不能为空"})


        # 3. 业务逻辑处理：增数据
        user = UserInfo.objects.get(phone=phone)
        new = News.objects.create(
            title = title,
            text = text,
            address = address,
            user = user
        )
        if image_list:
            try:
                defualt_image = image_list[0]
                new.defulat_image = defualt_image
                new.save()
            except Exception as e:
                print(e)

            try:
                for image in image_list:
                    New_image.objects.create(
                        new = new,
                        image = image
                    )
            except Exception as e:
                print(e)

        try:
            topic = Topic.objects.create(title=topic)
            New_Topic.objects.create(
                new=new,
                top=topic
            )
        except Exception as e:
            print(e)

        # 4. 返回响应
        return Response({"success":True,"msg":"ok"})


    @action(methods=['get'], url_path='credential', detail=False)
    def credential(self, request):
        """
        从腾讯云中获取临时秘钥，传递给前端
        :param request: 
        :return: response（临时秘钥）
        """
        config = {
            'url': 'https://sts.tencentcloudapi.com/',
            'domain': 'sts.tencentcloudapi.com',
            # 临时密钥有效时长，单位是秒
            'duration_seconds': 1800,
            'secret_id': settings.Tencent_SecretId,
            # 固定密钥
            'secret_key': settings.Tencent_SecretKey,
            # 设置网络代理
            # 'proxy': {
            #     'http': 'xx',
            #     'https': 'xx'
            # },
            # 换成你的 bucket
            'bucket': 'mini-1304965071',
            # 换成 bucket 所在地区
            'region': 'ap-chengdu',
            # 这里改成允许的路径前缀，可以根据自己网站的用户登录态判断允许上传的具体路径
            # 例子： a.jpg 或者 a/* 或者 * (使用通配符*存在重大安全风险, 请谨慎评估使用)
            'allow_prefix': '*',
            # 密钥的权限列表。简单上传和分片需要以下的权限，其他权限列表请看 https://cloud.tencent.com/document/product/436/31923
            'allow_actions': [
                # 简单上传
                'name/cos:PostObject',
                'name/cos:DeleteObject'
            ],
        }

        try:
            sts = Sts(config)
            response = sts.get_credential()

            return Response(response)
        except Exception as e:
            return Response({"statu": False, "message": "获取秘钥失败"})

