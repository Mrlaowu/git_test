from django.db import models
from app.user.models import UserInfo
from db.Basemodels import BaseModel

# Create your models here.

class News(BaseModel):
    title = models.CharField(max_length=20,verbose_name="标题")
    default_image = models.CharField(max_length=100,verbose_name="默认图片的url")
    text = models.CharField(max_length=100,verbose_name="新闻正文")
    comment_amount = models.IntegerField(null=True,verbose_name="评论数量")
    user = models.ForeignKey(UserInfo,verbose_name="用户")
    like_amount = models.IntegerField(null=True,verbose_name="点赞数量")
    address = models.CharField(max_length=20,verbose_name="位置")

    class Meta:
        managed = True

class New_detail(BaseModel):

    new = models.ForeignKey("News",verbose_name="新闻",on_delete=models.CASCADE)
    user = models.ForeignKey(UserInfo,verbose_name="用户",on_delete=models.CASCADE)
    comment = models.CharField(max_length=30,verbose_name="评论",null=True)

    class Meta:
        managed = True

class New_image(BaseModel):
    new = models.ForeignKey("News",verbose_name="新闻",on_delete=models.CASCADE)
    image = models.CharField(max_length=100,verbose_name="图片的url")

    class Meta:
        managed = True

class Topic(BaseModel):
    title = models.CharField(max_length=20,verbose_name="标题")

    class Meta:
        managed = True

class New_Topic(BaseModel):
    new = models.ForeignKey("News",verbose_name="新闻",on_delete=models.CASCADE)
    top = models.ForeignKey("Topic",verbose_name="话题",on_delete=models.CASCADE)

    class Meta:
        managed = True