from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.decorators import action
from rest_framework import viewsets
from libs.yuntongxun.example.SendMessage import send_message
from serializer.Ser_check import MessageSerializer,LoginSerializer
from django_redis import get_redis_connection
import re
import os
import random
import uuid
from app.user.models import UserInfo
from Auction import settings
import json

from sts.sts import Sts


class UserViewSet(viewsets.ViewSet):

    @action(methods=['get'],url_path="message",detail=False)
    def Message(self,request):
        """
        获取短信验证码、将其存储到redis中
        :return: {
            success:True 
        }
        """

        # 1. 获取手机号
        phone = request.query_params.get("phone")
        # 2. 手机格式校验
        ser = MessageSerializer(data = phone)
        if not ser.is_valid:
            return Response({"statu":False,"message":"手机格式错误"})

        # 3. 将验证码+手机号保留(60s)
        # 存入redis中: 存入之前判断该验证码是否在60s之内
        # redis: 1.phone: code  2.phone_status:1
        conn = get_redis_connection()
        try:
            phone_status = conn.get("%s_status"%phone)
            if phone_status:
                return Response({"statu":False,"message":"用户操作太频繁"})
        except Exception as e:
            print(e)

        # 4. 业务逻辑处理： 1. 生成随机数  2. 将验证码发入到手机中
        random_num = random.randint(10000,99999)
        try:
            send_message(phone,(" ---有人闯入！！ ",))
        except Exception as e:
            print(e)
            return Response({"statu":False,"message":"发送验证码异常"})


        conn.setex(phone,20,random_num)
        conn.setex("%s_status"%phone,20,"1")

        return Response({"statu":True})



    @action(methods=['post'],url_path='login',detail=False)
    def login(self,request):
        """
        根据手机号、验证码进行用户登录
        param:
            phone: "手机号"
            code: "验证码"
        return: 
            {
                statu: True
                data:{
                    phone:xxx,
                    token:yyy
                }
            }
        """

        # 1. 获取手机号、验证码
        phone = request.data.get("phone")
        code = request.data.get('code')

        # 2. 对相关参数进行验证
        ser_validator = LoginSerializer(data = request.data)
        if not all([phone,code]):
            return Response({"statu":False,"message":"手机号/验证码不能为空"})

        if not ser_validator.is_valid():
            return Response({"statu":False,"message":"短信验证码错误"})

        # 3. 业务逻辑处理：
            # 1. 保存用户信息(phone、token)

        # user = UserInfo.objects.filter(phone=phone)
        # if not user:
        #     UserInfo.objects.create(
        #         phone = phone,
        #         token = str(uuid.uuid4())
        #     )
        # else:
        #     user.token = str(uuid.uuid4())
        #     user.save()

        # 新写法 : 有数据则查询 无数据则创建
        user,flag = UserInfo.objects.get_or_create(phone=phone)
        user.token = str(uuid.uuid4())
        user.save()

        return Response({"statu":True,"data":{"token":user.token,'phone':phone}})

