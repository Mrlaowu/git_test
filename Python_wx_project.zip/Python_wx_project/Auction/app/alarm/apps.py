from django.apps import AppConfig


class AlarmConfig(AppConfig):
    name = 'app.alarm'
