from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.decorators import action
from rest_framework import viewsets
from minio import Minio
from Auction.settings import BASE_DIR
from minio.error import MinioException
from libs.yuntongxun.example.SendMessage import send_message
from serializer.Ser_check import MessageSerializer,LoginSerializer
from django_redis import get_redis_connection
import re
import os
import random
import uuid
from app.user.models import UserInfo
from Auction import settings
from datetime import datetime
import json

import os

from sts.sts import Sts

Image_list = []


class AlarmViewSet(viewsets.ViewSet):

    def __ImageFile(self):
        """
        功能:
            获取Image文件下的所有文件名,返回需要上传的文件名
        :return: uploadFile 
        """
        global Image_list
        filePath = BASE_DIR+"\\image"
        file_list = os.listdir(filePath)
        if Image_list != file_list:
            Image_list = file_list
            return Image_list[-1]

        return None


    @action(methods=['get'],url_path="images",detail=False)
    def Images(self,request):
        """
        实现功能：
            1. 接收图片，将图片上传到minio服务器中
            2. minio上传成功后，邮件/短信通知用户前往mino查看图片
        
        :param request: 
        :return: 
        """
        # 1. 获取需要上传的图片
        uploadFile = self.__ImageFile()
        if not uploadFile:
            return Response({"success":False,"msg":"未捕捉到任何东西"})

        # 2. 上传图片到minio服务器上
        try:
            minioClient = Minio('192.168.198.1:9000',
                                access_key='minioadmin',
                                secret_key='minioadmin',
                                secure=False)
        except Exception as ex:
            return Response({"success":False,"msg":"连接minio失败"})

        # 获取当前时间戳
        # date = str(datetime.now().year)+str(datetime.now().month)+str(datetime.now().day)+str(datetime.now().hour)+str(datetime.now().minute)
        try:
            minioClient.fput_object("mybucket", uploadFile,BASE_DIR+"\image\\"+uploadFile)
        except Exception as ex:
            return Response({"success":False,"msg":"上传图片失败"})
        print(BASE_DIR+"\image\\01.jpg")

        # 3. 短信提醒用户 -- 有人入侵
        phone = "18279096293"
        send_message(phone, (" \n \n--------有人闯入！！------\n \n ",))
        return Response({"status":200})
