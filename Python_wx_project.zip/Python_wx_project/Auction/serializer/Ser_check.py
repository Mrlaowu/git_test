from rest_framework import serializers
from rest_framework.exceptions import ValidationError
import re
from django_redis import get_redis_connection


def phone_validator(value):
    if not re.match(r"^1[3456789]\d{9}$",value):
        raise ValidationError("手机格式错误")

class NewsSerializer(serializers.Serializer):
    phone = serializers.CharField(label="手机号",required=True)
    title = serializers.CharField(label="标题",required=True)
    text = serializers.CharField(label="正文",required=True)

class MessageSerializer(serializers.Serializer):
    "校验手机号"
    phone = serializers.CharField(label="手机号",validators=[phone_validator,])


class LoginSerializer(serializers.Serializer):
    "校验登录"
    phone = serializers.CharField(label="手机号",validators=[phone_validator,])
    code = serializers.CharField(label="验证码")

    def validate_code(self,value):
        """ 
        校验短信验证码
        param:  code
        return: value
        """
        if len(value) != 5 or not value.isdigit():
            raise ValidationError("短信验证码格式错误")

        phone = self.initial_data.get("phone")
        conn = get_redis_connection()
        code = conn.get(phone)

        if not code:
            raise ValidationError("验证码过期")

        if value != code.decode("utf-8"):
            raise ValidationError("验证码错误")

        return value