from ronglian_sms_sdk import SmsSDK
import json

accId = '8aaf07087291adde01729b69e38c0571'
accToken = '7d168aa81a3e4315ae143e2dedde1d00'
appId = '8aaf07087291adde01729b69e4850578'

def send_message(mobile,datas):
    """
    :param mobile: 手机号码    type:str
    :param datas:  手机验证码  type:tuple
    :return:       "000000":发送成功
    """
    sdk = SmsSDK(accId, accToken, appId)
    tid = "1"
    result = sdk.sendMessage(tid, mobile, datas)

    if "000000" in result:
        # 发送成功
        return "发送成功"
    else:
        return "发送失败"


