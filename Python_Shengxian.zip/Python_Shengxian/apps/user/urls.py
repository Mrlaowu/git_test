from django.conf.urls import url
from user.views import RegisterView,ActiveView,LoginView,UserInfoView,UserOrderView,UserSiteView,LogoutView
from django.contrib.auth.decorators import login_required

urlpatterns=[
    # url(r'^register$',views.register,name='register'),#注册
    url(r'^register$',RegisterView.as_view(),name='register'),#注册
    url(r'^active/(?P<token>.*)$',ActiveView.as_view(),name='active'),#用户
    url(r'^login$',LoginView.as_view(),name='login'),#登录
    # url(r'^$',login_required(UserInfoView.as_view()),name='info'),#用户信息
    # url(r'^order$',login_required(UserOrderView.as_view()),name='order'),#用户订单
    # url(r'^site$',login_required(UserSiteView.as_view()),name='site'),#用户地址
	url(r'^$',UserInfoView.as_view(),name='info'),#用户信息
	url(r'^order/(?P<page>\d+)$',UserOrderView.as_view(),name='order'),#用户订单
	url(r'^site$',UserSiteView.as_view(),name='site'),#用户地址
	url(r'^logout$',LogoutView.as_view(),name='logout'),#用户退出
]