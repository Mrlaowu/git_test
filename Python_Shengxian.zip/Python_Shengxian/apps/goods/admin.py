from django.contrib import admin
from goods.models import GoodsType,IndexGoodsBanner,IndexPromotionBanner,GoodsImage,IndexTypeGoodsBanner,Goods,GoodsSKU
from django.core.cache import cache
class BaseAdmin(admin.ModelAdmin):
    """模型管理基类"""
    def save_model(self, request, obj, form, change):
        """新增或更新表中的数据时调用"""
        super().save_model(request,obj,form,change)
        #发出任务,让celery worker重新生成首页静态页  --异步
        from celery_tasks.tasks import generate_static_index_html
        generate_static_index_html.delay()

    def delete_model(self, request, obj):
        """删除表中的数据时调用"""
        super().delete_model(request,obj)
        #发出任务，让celery worker重新生成首页静态页
        from celery_tasks.tasks import generate_static_index_html
        generate_static_index_html.delay()

        #清除首页的缓存数据
        cache.delete('index_page_data')

class GoodsSKUAdmin(BaseAdmin):
    """SKU商品模型管理类"""
    list_display = ['goods','name','unite']

class IndexTypeGoodsBannerAdmin(BaseAdmin):
    """首页分类模型管理类"""
    list_display = ['sku','display_type']

class IndexGoodsBannerAdmin(BaseAdmin):
    """轮播图模型管理类"""
    list_display = ['sku','image']

class IndexPromotionBannerAdmin(BaseAdmin):
    """促销活动模型管理类"""
    pass

class GoodsTypeAdmin(BaseAdmin):
    """商品种类模型管理类"""
    pass

admin.site.register(GoodsType)
admin.site.register(IndexGoodsBanner,IndexGoodsBannerAdmin)
admin.site.register(IndexTypeGoodsBanner,IndexTypeGoodsBannerAdmin)
admin.site.register(IndexPromotionBanner,IndexPromotionBannerAdmin)
admin.site.register(GoodsImage)
admin.site.register(Goods)
admin.site.register(GoodsSKU,GoodsSKUAdmin)
