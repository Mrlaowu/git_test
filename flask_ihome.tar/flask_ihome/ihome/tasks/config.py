#coding:utf-8

#配置中间人broker
BROKER_URL="redis://127.0.0.1:6379/1"
#配置存放的结果--backend
CELERY_RESULT_BACKEND="redis://127.0.0.1:6379/2"